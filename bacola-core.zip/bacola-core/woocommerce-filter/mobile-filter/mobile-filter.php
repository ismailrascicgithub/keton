<?php
/*************************************************
* Mobile Filter
*************************************************/
add_action('bacola_mobile_bottom_menu', 'bacola_mobile_filter'); 
function bacola_mobile_filter() { 

	$mobilebottommenu = get_theme_mod('bacola_mobile_bottom_menu','0');
	if($mobilebottommenu == '1'){

?>

	<?php $edittoggle = get_theme_mod('bacola_mobile_bottom_menu_edit_toggle','0'); ?>
	<?php if($edittoggle == '1'){ ?>
		<nav class="header-mobile-nav">
			<div class="mobile-nav-wrapper">
				<ul>
					<?php $editrepeater = get_theme_mod('bacola_mobile_bottom_menu_edit'); ?>
					
					<?php foreach($editrepeater as $e){ ?>
						<?php if($e['mobile_menu_type'] == 'filter'){ ?>
							<?php if(is_shop()){ ?>
								<li class="menu-item">
									<a href="#" class="filter-toggle">
										<i class="klbth-icon-<?php echo esc_attr($e['mobile_menu_icon']); ?>"></i>
										<span><?php echo esc_html($e['mobile_menu_text']); ?></span>
									</a>
								</li>
							<?php } ?>
						<?php } elseif($e['mobile_menu_type'] == 'search'){ ?>
							<li class="menu-item">
								<a href="#" class="search">
									<i class="klbth-icon-<?php echo esc_attr($e['mobile_menu_icon']); ?>"></i>
									<span><?php echo esc_html($e['mobile_menu_text']); ?></span>
								</a>
							</li>
						<?php } elseif($e['mobile_menu_type'] == 'category'){ ?>
							<?php if(!is_shop()){ ?>
								<li class="menu-item">
									<a href="#" class="categories">
										<i class="klbth-icon-<?php echo esc_attr($e['mobile_menu_icon']); ?>"></i>
										<span><?php echo esc_html($e['mobile_menu_text']); ?></span>
									</a>
								</li>
							<?php } ?>
						<?php } else { ?>
							<li class="menu-item">
								<a href="<?php echo esc_url($e['mobile_menu_url']); ?>" class="user">
									<i class="klbth-icon-<?php echo esc_attr($e['mobile_menu_icon']); ?>"></i>
									<span><?php echo esc_html($e['mobile_menu_text']); ?></span>
								</a>
							</li>
						<?php } ?>
					<?php } ?>
				
				</ul>
			</div>
		</nav>
	<?php } else { ?>
		<nav class="header-mobile-nav">
			<div class="mobile-nav-wrapper">
				<ul>
                  <li class="menu-item">
						<?php if(!is_shop()){ ?>
							<a href="<?php echo wc_get_page_permalink( 'shop' ); ?>" class="store" title="<?php esc_html_e('Store','bacola-core'); ?>">
                              <svg width="24" height="21" viewBox="0 0 24 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M21.062 11.9266C19.8457 11.9266 18.7281 11.3258 18.0406 10.375C17.3532 11.3258 16.2356 11.9266 15.0193 11.9266C13.803 11.9266 12.6854 11.3258 11.9979 10.375C11.3104 11.3258 10.1928 11.9266 8.97652 11.9266C7.76021 11.9266 6.64262 11.3258 5.95515 10.375C5.26767 11.3258 4.15008 11.9266 2.93377 11.9266C2.8615 11.9266 2.78746 11.9249 2.71519 11.9196C2.35911 11.8984 2.01361 11.8241 1.6875 11.7022V18.2481C1.6875 19.7644 2.91438 20.9944 4.42683 20.9944H9.16513V15.1145H14.8359V20.9944H19.5742C21.0867 20.9944 22.3136 19.7644 22.3136 18.2481V11.7022C21.9857 11.8241 21.6402 11.8984 21.2859 11.9196C21.2136 11.9231 21.1396 11.9266 21.0673 11.9266H21.062Z" fill="#162A7C"/>
                                <path d="M23.9096 6.47698L22.5153 0.848281C22.3919 0.349916 21.9459 0 21.4329 0H2.57313C2.06193 0 1.61595 0.349916 1.49079 0.846514L0.0911607 6.47521C-0.264917 7.90492 0.45429 9.35053 1.68822 9.94256C2.01257 10.0981 2.37217 10.197 2.75646 10.2183C2.81463 10.2218 2.87456 10.2236 2.9345 10.2236C4.14022 10.2236 5.18025 9.51666 5.66501 8.49342C5.73552 8.3432 5.79546 8.18768 5.84129 8.02509C5.85892 7.96501 5.90651 7.93673 5.95587 7.93673C6.00523 7.93673 6.05458 7.96678 6.07045 8.02509C6.11628 8.18768 6.17621 8.3432 6.24672 8.49342C6.73148 9.51666 7.77151 10.2236 8.97724 10.2236C10.183 10.2236 11.223 9.51666 11.7078 8.49342C11.7783 8.3432 11.8382 8.18768 11.884 8.02509C11.9017 7.96501 11.9493 7.93673 11.9986 7.93673C12.048 7.93673 12.0973 7.96678 12.1132 8.02509C12.159 8.18768 12.219 8.3432 12.2895 8.49342C12.7742 9.51666 13.8143 10.2236 15.02 10.2236C16.2257 10.2236 17.2657 9.51666 17.7505 8.49342C17.821 8.3432 17.881 8.18768 17.9268 8.02509C17.9444 7.96501 17.992 7.93673 18.0414 7.93673C18.0907 7.93673 18.1401 7.96678 18.1559 8.02509C18.2018 8.18768 18.2617 8.3432 18.3322 8.49342C18.817 9.51666 19.857 10.2236 21.0627 10.2236C21.1227 10.2236 21.1808 10.2236 21.2408 10.2183C21.6268 10.1953 21.9864 10.0981 22.309 9.94256C23.5412 9.34877 24.2604 7.90492 23.9061 6.47698H23.9096Z" fill="#162A7C"/>
                              </svg>
                            </a>
						<?php } else { ?>
							<a href="<?php echo esc_url( home_url( "/" ) ); ?>" class="store" title="<?php esc_html_e('Home','bacola-core'); ?>">
                              <svg width="20" height="22" viewBox="0 0 20 22" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M0 19V8.06667L10 0L20 8.06667V19C20 20.6569 18.6569 22 17 22H13.6364V11.9167H6.36364V22H3C1.34315 22 0 20.6569 0 19Z" fill="#162A7C"/>
                              </svg>
							</a>
						<?php } ?>
					</li>
					<?php if(is_shop()){ ?>
						<li class="menu-item">
							<a href="#" class="filter-toggle">
                              <svg width="24" height="20" viewBox="0 0 24 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M0.182589 1.02235C0.492 0.397334 1.14833 0 1.87497 0H22.1273C22.854 0 23.5103 0.397334 23.8197 1.02235C24.1291 1.64737 24.0354 2.384 23.576 2.91973L15.0015 12.8977V18.572C15.0015 19.1122 14.6827 19.6077 14.1717 19.8488C13.6607 20.0899 13.056 20.0408 12.6012 19.7149L9.60088 17.572C9.22115 17.3041 9.00081 16.88 9.00081 16.4291V12.8977L0.421679 2.91527C-0.0330613 2.384 -0.13151 1.64291 0.182589 1.02235Z" fill="#162A7C"/>
                              </svg>
							</a>
						</li>
					<?php } ?>

					<li class="menu-item">
						<a href="#" class="search">
                          <svg width="23" height="23" viewBox="0 0 23 23" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M18.6884 9.34238C18.6884 11.404 18.019 13.3084 16.8915 14.8535L22.5788 20.5443C23.1404 21.1057 23.1404 22.0175 22.5788 22.5789C22.0173 23.1404 21.1053 23.1404 20.5438 22.5789L14.8564 16.8882C13.311 18.02 11.4062 18.6848 9.34421 18.6848C4.18243 18.6848 0 14.5031 0 9.34238C0 4.18161 4.18243 0 9.34421 0C14.506 0 18.6884 4.18161 18.6884 9.34238ZM9.34421 15.8102C10.1937 15.8102 11.0349 15.6429 11.8198 15.3179C12.6047 14.9928 13.3178 14.5164 13.9185 13.9158C14.5192 13.3152 14.9957 12.6022 15.3208 11.8175C15.6459 11.0328 15.8133 10.1917 15.8133 9.34238C15.8133 8.49302 15.6459 7.65197 15.3208 6.86726C14.9957 6.08255 14.5192 5.36955 13.9185 4.76895C13.3178 4.16836 12.6047 3.69195 11.8198 3.36691C11.0349 3.04187 10.1937 2.87458 9.34421 2.87458C8.49468 2.87458 7.65347 3.04187 6.8686 3.36691C6.08374 3.69195 5.37059 4.16836 4.76989 4.76895C4.16918 5.36955 3.69267 6.08255 3.36757 6.86726C3.04247 7.65197 2.87514 8.49302 2.87514 9.34238C2.87514 10.1917 3.04247 11.0328 3.36757 11.8175C3.69267 12.6022 4.16918 13.3152 4.76989 13.9158C5.37059 14.5164 6.08374 14.9928 6.8686 15.3179C7.65347 15.6429 8.49468 15.8102 9.34421 15.8102Z" fill="#162A7C"/>
                          </svg>
						</a>
					</li>
					
					<?php if ( function_exists( 'tinv_url_wishlist_default' ) ) { ?>
						<li class="menu-item">
							<?php echo do_shortcode('[ti_wishlist_products_counter]'); ?>
						</li>
					<?php } ?>
					
					<li class="menu-item">
						<?php $headeraccounticon  = get_theme_mod('bacola_header_account','0'); ?>
                        <?php if($headeraccounticon){ ?>
                        <a href="<?php echo wc_get_page_permalink( 'myaccount' ); ?>" role="button" class="header_user_icon user">
                          <svg width="26" height="28" viewBox="0 0 26 28" fill="none" xmlns="http://www.w3.org/2000/svg" class="user-icon<?php echo (is_user_logged_in() ? '-logged' : ''); ?>">
                            <path d="M9.29249 11.2137C10.7008 11.2137 12.0514 10.6543 13.0472 9.65848C14.043 8.66266 14.6025 7.31204 14.6025 5.90374C14.6025 4.49545 14.043 3.14483 13.0472 2.14901C12.0514 1.15319 10.7008 0.59375 9.29249 0.59375C7.88419 0.59375 6.53357 1.15319 5.53776 2.14901C4.54194 3.14483 3.9825 4.49545 3.9825 5.90374C3.9825 7.31204 4.54194 8.66266 5.53776 9.65848C6.53357 10.6543 7.88419 11.2137 9.29249 11.2137ZM7.39666 13.205C3.31045 13.205 0 16.5154 0 20.6016C0 21.282 0.551742 21.8337 1.23208 21.8337H17.3529C18.0332 21.8337 18.585 21.282 18.585 20.6016C18.585 16.5154 15.2745 13.205 11.1883 13.205H7.39666Z" fill="#162A7C"/>
                            <rect x="11.5" y="13.5" width="14" height="14" rx="7" fill="#5EAF00" stroke="white"/>
                            <path d="M15 20.5L17.3077 23L21.5 19" stroke="white" stroke-linecap="round" stroke-linejoin="round"/>
                          </svg>
                        </a>
                        <?php } ?>
					</li>

					<?php $sidebarmenu = get_theme_mod('bacola_header_sidebar','0'); ?>
					<?php if($sidebarmenu == '1'){ ?>
						<?php if(!is_shop()){ ?>
							<li class="menu-item">
								<a href="#" class="categories">
									<i class="klbth-icon-menu-thin"></i>
									<span><?php esc_html_e('Categories','bacola-core'); ?></span>
								</a>
							</li>
						<?php } ?>
					<?php } ?>

				</ul>
			</div><!-- mobile-nav-wrapper -->
		</nav><!-- header-mobile-nav -->
	<?php } ?>
	
<?php }

    
}