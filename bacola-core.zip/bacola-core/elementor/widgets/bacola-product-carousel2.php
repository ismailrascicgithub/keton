<?php
namespace Elementor;

class Bacola_Product_Carousel_Widget2 extends Bacola_Product_Carousel_Widget
{

    public function get_name()
    {
        return 'bacola_product_carousel2';
    }

    public function get_title(): string
    {
        return __('Bacola Product Carousel 2', 'text-domain');
    }



    protected function render()
    {
        $settings = $this->get_settings_for_display();
        $target = $settings['btn_link']['is_external'] ? ' target="_blank"' : '';
        $nofollow = $settings['btn_link']['nofollow'] ? ' rel="nofollow"' : '';

        $output = '';

        $output .= '<div class="site-module module-carousel">';
        if ($settings['title'] || $settings['subtitle']) {
            $output .= '<div class="module-header">';
            $output .= '<div class="column">';
            $output .= '<h4 class="entry-title">' . esc_html($settings['title']) . '</h4>';
            $output .= '<div class="entry-description">' . esc_html($settings['subtitle']) . '</div>';
            $output .= '</div>';
            $output .= '<div class="column">';
            if ($settings['btn_title']) {
                $output .= '<a class="button button-info-default xsmall rounded" href="' . esc_url($settings['btn_link']['url']) . '" ' . esc_attr($target . $nofollow) . '>' . esc_html($settings['btn_title']) . ' <i class="klbth-icon-right-arrow"></i></a>';
            }
            $output .= '</div>';
            $output .= '</div>';
        }
        $output .= '<div class="module-body">';
        $output .= '<div class="slider-wrapper">';
        $output .= '<svg class="preloader" width="65px" height="65px" viewBox="0 0 66 66" xmlns="http://www.w3.org/2000/svg"><circle class="path" fill="none" stroke-width="6" stroke-linecap="round" cx="33" cy="33" r="30"></circle></svg>';
        $output .= '<div class="carousel-products2 products site-slider" data-slideshow="' . esc_attr($settings['column']) . '" data-mobile-only="' . esc_attr($settings['mobile_only']) . '" data-mobile="' . esc_attr($settings['mobile_column']) . '" data-slidespeed="' . esc_attr($settings['slide_speed']) . '" data-arrows="' . esc_attr($settings['arrows']) . '" data-autoplay="' . esc_attr($settings['auto_play']) . '" data-autospeed="' . esc_attr($settings['auto_speed']) . '" data-dots="' . esc_attr($settings['dots']) . '">';

        $output .= $this->bacola_elementor_product_loop($settings);

        $output .= '</div>';
        $output .= '</div>';
        $output .= '</div>';
        $output .= '</div>';

        echo $output;
    }

}
