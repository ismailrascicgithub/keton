<?php
namespace Elementor;

class Bacola_Product_Grid_Widget3 extends Bacola_Product_Grid_Widget
{

    public function get_name()
    {
        return 'bacola_product_grid3';
    }

    public function get_title(): string
    {
        return __('Bacola Product Grid 3', 'text-domain');
    }

    protected function render()
    {
        $settings = $this->get_settings_for_display();
        $target = $settings['btn_link']['is_external'] ? ' target="_blank"' : '';
        $nofollow = $settings['btn_link']['nofollow'] ? ' rel="nofollow"' : '';

        $output = '';

        $output .= '<div class="site-module module-products">';
        if ($settings['title'] || $settings['subtitle']) {
            $output .= '<div class="module-header">';
            $output .= '<div class="column">';
            $output .= '<h4 class="entry-title">' . esc_html($settings['title']) . '</h4>';
            $output .= '<div class="entry-description">' . esc_html($settings['subtitle']) . '</div>';
            $output .= '</div><!-- column -->';
            $output .= '<div class="column">';
            $output .= '<a href="' . esc_url($settings['btn_link']['url']) . '" ' . esc_attr($target . $nofollow) . ' class="button button-info-default xsmall rounded">' . esc_html($settings['btn_title']) . ' <i class="klbth-icon-right-arrow"></i></a>';
            $output .= '</div><!-- column -->';
            $output .= '</div><!-- module-header -->';
        }
        $output .= '<div class="module-body">';
        $output .= '<div class="grid-products3 products column-' . esc_attr($settings['column']) . ' mobile-column-' . esc_attr($settings['mobile_column']) . '">';

        $output .= $this->bacola_elementor_product_loop($settings);

        $output .= '</div>';
        $output .= '</div>';
        $output .= '</div>';

        echo $output;
    }
}
